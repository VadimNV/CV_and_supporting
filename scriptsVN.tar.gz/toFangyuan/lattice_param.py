import math

def set_lat_param(sym):
    if sym=='Cubic' or sym=='cubic' :
        #       _| cubic primitive   |_
        a        =   4.000                             # [Angstrom] Wang2010 Exp.
        Ba       = [[ 0.0     , 0.0     , 0.0     ]]   # Wyckoff positions from Evarestov2012, Ghosez1999a
        Ti       = [[ 0.5     , 0.5     , 0.5     ]]   # atomic positions Mahmoud2014
        Ox       = [[ 0.5     , 0.5     , 0.0     ],
                    [ 0.5     , 0.0     , 0.5     ],
                    [ 0.0     , 0.5     , 0.5     ]]
        #       ... assuming 'simple cubic/primitive cubic (cP)' from "High-throughput electronic band structure calculations: challenges and tools. Wahyu Setyawan, Stefano Curtarolo"
                                                       # see also https://en.wikipedia.org/wiki/Cubic_crystal_system , Ghosez1999, 
        #       ... Evarestov2012 defines it as (Pm-3m), SG 221. From wiki: point group class = Hexoctahedral(Oh)
        aAll     = [[ 1.0     , 0.0     , 0.0     ],   # a1
                    [ 0.0     , 1.0     , 0.0     ],   # a2
                    [ 0.0     , 0.0     , 1.0     ]]   # a3
    elif sym=='R3m' :
        #       _| rhombohedral(R3m) |_
        a        =   4.004                             # [Angstrom] Mahmoud2014 Exp.
        alpha    =   89.839                            # [degrees] Mahmoud2014 Exp.
        xTi      =  -0.0128                            # Mahmoud2014 Exp.
        xO       =   0.0109
        zO       =   0.0193
        Ba       = [[ 0.0     , 0.0     , 0.0     ]]   # Wyckoff positions from Evarestov2012, Ghosez1999a
        Ti       = [[ 0.5+xTi , 0.5+xTi , 0.5+xTi ]]   # atomic positions Mahmoud2014
        Ox       = [[ 0.5+xO  , 0.5+xO  , 0.0+zO  ],
                    [ 0.5+xO  , 0.0+zO  , 0.5+xO  ],
                    [ 0.0+zO  , 0.5+xO  , 0.5+xO  ]]
        #       ... assuming 'rhombohedral(hR) RHL_1 (alpha<90)' from "High-throughput electronic band structure calculations: challenges and tools. Wahyu Setyawan, Stefano Curtarolo"
        #       ... Evarestov2012 defines it as (R3m), SG 160. 
        alphRd   = math.pi*(alpha/180.0)
        sAo2     = math.sin(alphRd/2.0)
        cAo2     = math.cos(alphRd/2.0)
        cA       = math.cos(alphRd    )
        r        = cA/cAo2
        lt       = math.sqrt(1.0 - r**2)
        aAll     = [[ a*cAo2  ,-a*sAo2  , 0.0     ],   # a1
                    [ a*cAo2  , a*sAo2  , 0.0     ],   # a2
                    [ a*r     , 0.0     , a*lt    ]]   # a3
    return a,aAll,Ba,Ti,Ox

def set_lat_paramR3m_custom(x):
    #       _| rhombohedral(R3m) |_
    a        = x[0]                                # ~  4.004  # [Angstrom] Mahmoud2014 Exp.
    alpha    = x[1]                                # ~  89.839 # [degrees] Mahmoud2014 Exp.
    xTi      = x[2]                                # ~ -0.0128 # Mahmoud2014 Exp.
    xO       = x[3]                                # ~  0.0109
    zO       = x[4]                                # ~  0.0193
    Ba       = [[ 0.0     , 0.0     , 0.0     ]]   # Wyckoff positions from Evarestov2012, Ghosez1999a
    Ti       = [[ 0.5+xTi , 0.5+xTi , 0.5+xTi ]]   # atomic positions Mahmoud2014
    Ox       = [[ 0.5+xO  , 0.5+xO  , 0.0+zO  ],
                [ 0.5+xO  , 0.0+zO  , 0.5+xO  ],
                [ 0.0+zO  , 0.5+xO  , 0.5+xO  ]]
    #       ... assuming 'rhombohedral(hR) RHL_1 (alpha<90)' from "High-throughput electronic band structure calculations: challenges and tools. Wahyu Setyawan, Stefano Curtarolo"
    #       ... Evarestov2012 defines it as (R3m), SG 160. 
    alphRd   = math.pi*(alpha/180.0)
    sAo2     = math.sin(alphRd/2.0)
    cAo2     = math.cos(alphRd/2.0)
    cA       = math.cos(alphRd    )
    r        = cA/cAo2
    lt       = math.sqrt(1.0 - r**2)
    aAll     = [[ a*cAo2  ,-a*sAo2  , 0.0     ],   # a1
                [ a*cAo2  , a*sAo2  , 0.0     ],   # a2
                [ a*r     , 0.0     , a*lt    ]]   # a3
    return a,aAll,Ba,Ti,Ox
