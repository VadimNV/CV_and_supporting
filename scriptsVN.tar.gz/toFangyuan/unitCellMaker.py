import math
import lattice_param
auTOang  = 0.5291772108                                  # as in ASAP
#auTOang  = 0.52917720859                                # CODATA 2006 as in Wannier90 and Quantum Espresso
angTOau  = 1.0/auTOang
unitC    = 'bohr'
#unitC    = 'ang'
#unitP    = 'ang'
#unitP    = 'bohr'
unitP    = 'scaled'

#__| BaTiO3  |__
#pathASAP = 'bto/RXed_cel_pos/'
pathASAP = 'unitCellOUT/'
#symmetry = 'Cubic'
symmetry = 'R3m'
outSym = 'py'+symmetry
a,aAll,Ba,Ti,Ox = lattice_param.set_lat_param(symmetry)
#  | cel vec \__________________________________________
fCel     = open(pathASAP+outSym+'_'+unitC+'.cel','w')   # write this unit cell to file compatible with asap
if unitC == 'ang' :                                     # assuming cell vectors are specified in Angstroms. Hence conversion via:
    fCel.write('angstrom'+'\n')
    fCel.write("\n")
    u    = 1.0*a                                        # conversion of scaled to Angstrom
else             :
    fCel.write("\n")
    u    = 1.0*a*angTOau                                # conversion of scaled to Ang to bohr (a.u.)
for ai in aAll:
    for item in ai:
        iu = item*u
        fCel.write("\t%s" % iu)
    fCel.write("\n")
fCel.close()
#             __________________________________________
#  |_________/
#
#  | pos vec \__________________________________________
fPos     = open(pathASAP+outSym+'_'+unitP+'.pos','w')   #       ...now position vectors
if   unitP == 'ang' :                                   #       ...for reduced/fractional coordinates see https://en.wikipedia.org/wiki/Fractional_coordinates . for r=[x,y,z] -> x*a1+ y*a2 + z*a3
    fPos.write('angstrom'+'\n')
    fPos.write("\n")
    u    = 1.0*a                                        # conversion of scaled to Angstrom
elif unitP =='bohr' :
    fPos.write("\n")
    u    = 1.0*a*angTOau                                # conversion of scaled to Ang to bohr
else                :
    fPos.write('scaled'+'\n')
    fPos.write("\n")
    u    = 1.0                                          # conversion of scaled to scaled (a.u.)

if unitP =='ang' or unitP=='bohr':
    for atm in Ba:
        fPos.write("Ba")
        pos = [0.0, 0.0, 0.0]
        for c,ai in zip(atm,aAll):
            pos[0]+=c*ai[0]*u
            pos[1]+=c*ai[1]*u
            pos[2]+=c*ai[2]*u
        for p in pos:
            fPos.write("\t%s" % p)
        fPos.write("\n")
    for atm in Ti:
        fPos.write("Ti")
        pos = [0.0, 0.0, 0.0]
        for c,ai in zip(atm,aAll):
            pos[0]+=c*ai[0]*u
            pos[1]+=c*ai[1]*u
            pos[2]+=c*ai[2]*u
        for p in pos:
            fPos.write("\t%s" % p)
        fPos.write("\n")
    for atm in Ox:
        fPos.write("O")
        pos = [0.0, 0.0, 0.0]
        for c,ai in zip(atm,aAll):
            pos[0]+=c*ai[0]*u
            pos[1]+=c*ai[1]*u
            pos[2]+=c*ai[2]*u
        for p in pos:
            fPos.write("\t%s" % p)
        fPos.write("\n")
else                             :
    for atm in Ba:
        fPos.write("Ba")
        for p in atm:
            fPos.write("\t%s" % p)
        fPos.write("\n")
    for atm in Ti:
        fPos.write("Ti")
        for p in atm:
            fPos.write("\t%s" % p)
        fPos.write("\n")
    for atm in Ox:
        fPos.write("O")
        for p in atm:
            fPos.write("\t%s" % p)
        fPos.write("\n")
fPos.close()
#             __________________________________________
#  |_________/
